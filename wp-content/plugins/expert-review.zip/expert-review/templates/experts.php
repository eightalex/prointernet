<?php

if ( ! defined( 'WPINC' ) ) {
	die;
}

use Wpshop\ExpertReview\Plugin;

/**
 * @var string $value
 * @var string $name
 */

$experts = $value ? json_decode( $value, true ) : []

?>
<div class="js-expert-form-wrapper">
    <input type="hidden" class="js-expert-data" value="<?php echo esc_js( $value ) ?>" name="<?php echo $name ?>">
    <ul class="expert-review-list js-expert-list"></ul>

    <div class="js-expert-form">
        <label><?php echo __( 'Avatar URL', Plugin::TEXT_DOMAIN ) ?>
<!--            <input type="text" class="js-expert-avatar">-->
            <input type="text" name="<?php echo '' ?>[my_popup_background_image]"
                   class="js-wpshop-form-element-url js-expert-avatar"
                   data-preview_param="bg_image:image">
            <button type="button"
                    class="button js-wpshop-form-element-browse"><?php echo __( 'Choose', Plugin::TEXT_DOMAIN ) ?></button>

        </label>
        <label><?php echo __( 'Name', Plugin::TEXT_DOMAIN ) ?>
            <input type="text" class="js-expert-name">
        </label>
        <label><?php echo __( 'Description', Plugin::TEXT_DOMAIN ) ?>
            <input type="text" class="js-expert-description">
        </label>
        <button class="button js-add-expert"><?php echo __( 'Add New Expert', Plugin::TEXT_DOMAIN ) ?></button>
    </div>

</div>
