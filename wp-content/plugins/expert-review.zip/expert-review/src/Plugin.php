<?php

namespace Wpshop\ExpertReview;

use Puc_v4_Factory;
use Wpshop\ExpertReview\Settings\PluginOptions;

class Plugin {

	const TEXT_DOMAIN = 'expert-review';

	/**
	 * @var null|bool
	 */
	protected $_verify;

	/**
	 * @var string
	 */
	public $name;

	/**
	 * @var string
	 */
	public $version;

	/**
	 * @var string
	 */
	protected $plugin_file;

	/**
	 * @var string
	 */
	protected $verify_url;

	/**
	 * @var string
	 */
	protected $update_url;

	/**
	 * @var string
	 */
	protected $update_slug;

	/**
	 * @var string
	 */
	protected $update_check_period;

	/**
	 * @var string
	 */
	protected $update_option_name;

	/**
	 * @var PluginOptions
	 */
	protected $options;

	/**
	 * Plugin constructor.
	 *
	 * @param array         $config
	 * @param PluginOptions $options
	 */
	public function __construct( array $config, PluginOptions $options ) {
		$this->configure( $config );
		$this->options = $options;
	}

	/**
	 * @param array $cnf
	 *
	 * @return void
	 */
	protected function configure( array $cnf ) {
		$update_cnf = $cnf['update'];

		$this->verify_url          = $cnf['verify_url'];
		$this->update_url          = $update_cnf['url'];
		$this->update_slug         = $update_cnf['slug'];
		$this->update_check_period = $update_cnf['check_period'];
		$this->update_option_name  = $update_cnf['opt_name'];
	}

	/**
	 * @param string $plugin_file
	 *
	 * @return bool
	 */
	public function init( $plugin_file ) {
		$this->plugin_file = $plugin_file;

		$this->load_languages();
		$this->init_metadata();
		add_action( 'admin_notices', function () {
			$this->license_notice();
		} );
		$this->enqueue_resources( $this->version );
		$this->init_updates();

		do_action( __METHOD__, $this );

		return true;
	}

	/**
	 * @return void
	 */
	protected function load_languages() {
		load_plugin_textdomain( static::TEXT_DOMAIN, false, dirname( plugin_basename( $this->plugin_file ) ) . '/languages/' );
	}

	/**
	 * @param string $version
	 *
	 * @return void
	 */
	protected function enqueue_resources( $version ) {

		if ( $this->verify() ) {
			add_action( 'wp_enqueue_scripts', function () use ( $version ) {
				wp_enqueue_style( 'expert-review-style', plugin_dir_url( __DIR__ ) . 'assets/public/css/styles.min.css', [], $version );
				wp_enqueue_script( 'expert-review-scripts', plugin_dir_url( __DIR__ ) . 'assets/public/js/scripts.min.js', [ 'jquery' ], $version, true );

				wp_localize_script( 'expert-review-scripts', 'expert_review_ajax', [
					'url'   => admin_url( 'admin-ajax.php' ),
					'nonce' => wp_create_nonce( 'wpshop-nonce' ),
				] );
			} );
		}

		add_action( 'admin_enqueue_scripts', function () use ( $version ) {
			wp_enqueue_style( 'expert-review-style', plugins_url() . '/expert-review/assets/admin/css/style.min.css', [], $version );
			wp_enqueue_script( 'expert-review-admin-scripts', plugins_url() . '/expert-review/assets/admin/js/scripts.min.js', [ 'jquery' ], $version, true );

			do_action( 'expert_review_admin_enqueue_scripts' );

			wp_localize_script( 'expert-review-admin-scripts', 'expert_review_globals', [
				'url'         => admin_url( 'admin-ajax.php' ),
				'nonce'       => wp_create_nonce( 'wpshop-nonce' ),
				'editor_icon' => plugins_url() . '/expert-review/assets/admin/images/tinymce-icon.png',
				'i18n'        => [
					'expert' => __( 'Expert', static::TEXT_DOMAIN ),
				],
			] );

			wp_enqueue_media();

			$browseSelector = '.js-wpshop-form-element-browse';
			$urlSelector    = '.js-wpshop-form-element-url';
			$js             = <<<"JS"
jQuery(function($) {
	\$('{$browseSelector}').on('click', function (event) {
	    event.preventDefault();

	    var self = $(this);

	    var fileFrame = wp.media.frames.file_frame = wp.media({
	        title: self.data('uploader_title'),
	        button: {
	            text: self.data('uploader_button_text'),
	        },
	        multiple: false
	    });

	    fileFrame.on('select', function () {
	        attachment = fileFrame.state().get('selection').first().toJSON();

	        self.prev('{$urlSelector}').val(attachment.url);
	        self.prev('{$urlSelector}').trigger('change');
	    });

	    fileFrame.open();
	});
});
JS;
			wp_add_inline_script( 'jquery', $js );
		} );


		// tinymce
		add_filter( 'mce_external_plugins', function ( $plugin_array ) {
			$plugin_array['expert_review_button'] = plugin_dir_url( __DIR__ ) . 'assets/admin/js/tinymce.min.js';

			return $plugin_array;
		} );

		add_filter( 'mce_buttons', function ( $buttons ) {
			//register buttons with their id.
			array_push(
				$buttons,
				'expert_review_button'
			);

			return $buttons;
		} );

		// gutenberg
		add_action( 'enqueue_block_editor_assets', function () use ( $version ) {
			wp_enqueue_style( 'expert-review-gutenberg-style', plugins_url() . '/expert-review/assets/admin/css/gutenberg.min.css', [ 'wp-edit-blocks' ], $version );
			wp_enqueue_script( 'expert-review-gutenberg-scripts', plugins_url() . '/expert-review/assets/admin/js/gutenberg.min.js', [
				'wp-blocks',
				'wp-element',
				'wp-editor',
			], $version, true );
		} );
	}

	/**
	 * @return void
	 */
	protected function init_metadata() {
//		add_action( 'plugins_loaded', function () {
		require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
		$data          = get_plugin_data( $this->plugin_file, false, false );
		$this->version = $data['Version'];
		$this->name    = $data['Name'];
//		} );
	}

	/**
	 * @return void
	 */
	public function init_updates() {
		if ( ! $this->verify() ) {
			return;
		}
		Puc_v4_Factory::buildUpdateChecker(
			$this->update_url,
			$this->plugin_file,
			$this->update_slug,
			$this->update_check_period,
			$this->update_option_name
		)->addQueryArgFilter( function ( $queryArgs ) {
			if ( $licence = $this->options->license ) {
				$queryArgs['license_key'] = $licence;
			}

			return $queryArgs;
		} )
		;
	}

	/**
	 * @return void
	 */
	protected function license_notice() {
		if ( ! $this->verify() ) {
			echo '<div class="notice notice-error">';
			echo '<h2>' . __( 'Attention!', static::TEXT_DOMAIN ) . '</h2>';
			echo '<p>' . sprintf( __( 'To activate plugin you need to enter the license key on <a href="%s">this page</a>.', static::TEXT_DOMAIN ), admin_url( 'options-general.php?page=expert-review' ) ) . '</p>';
			echo '</div>';
		}
	}

	/**
	 * @return bool
	 */
	public function verify() {
		if ( null === $this->_verify ) {
			$license        = $this->options->license;
			$license_verify = $this->options->license_verify;
			$license_error  = $this->options->license_error;

			if ( ! empty( $license ) && ! empty( $license_verify ) && empty( $license_error ) ) {
				//TODO: проверка на истечение лицензии
				$this->_verify = true;
			} else {
				$this->_verify = false;
			}
		}

		return $this->_verify;
	}

	/**
	 * @param string $license
	 *
	 * @return bool
	 */
	public function activate( $license ) {
		$url = trim( $this->verify_url );

		if ( ! $url ) {
			$this->options->license_verify = '';
			$this->options->license_error  = __( 'Unable to check license without activation url', static::TEXT_DOMAIN );

			return false;
		}

		$args = [
			'timeout'   => 15,
			'sslverify' => false,
			'body'      => [
				'action'    => 'activate_license',
				'license'   => $license,
				'item_name' => $this->name,
				'version'   => $this->version,
				'type'      => 'plugin',
				'url'       => home_url(),
				'ip'        => Utilities::get_ip(),
			],
		];

		$response = wp_remote_post( $url, $args );
		if ( is_wp_error( $response ) ) {
			$response = wp_remote_post( str_replace( "https", "http", $url ), $args );
		}

		if ( is_wp_error( $response ) ) {
			$this->options->license_verify = '';
			$this->options->license_error  = __( 'Can\'t get response from license server', $this->options->text_domain );

			return false;
		}

		$body = wp_remote_retrieve_body( $response );

		if ( mb_substr( $body, 0, 2 ) == 'ok' ) {
			$this->options->license        = $license;
			$this->options->license_verify = time() + ( WEEK_IN_SECONDS * 4 );
			$this->options->license_error  = '';

			return true;
		}

		$this->options->license_verify = '';
		$this->options->license_error  = $body;

		return false;
	}
}
