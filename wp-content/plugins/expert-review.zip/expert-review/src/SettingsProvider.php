<?php

namespace Wpshop\ExpertReview;

use Wpshop\ExpertReview\Settings\ExpertOptions;
use Wpshop\ExpertReview\Settings\PluginOptions;
use Wpshop\SettingApi\OptionField\Checkbox;
use Wpshop\SettingApi\OptionField\Color;
use Wpshop\SettingApi\OptionField\Number;
use Wpshop\SettingApi\OptionField\RawHtml;
use Wpshop\SettingApi\OptionField\Select;
use Wpshop\SettingApi\OptionField\Text;
use Wpshop\SettingApi\OptionField\Textarea;
use Wpshop\SettingApi\Section\Section;
use Wpshop\SettingApi\SettingsProviderInterface;
use Wpshop\SettingApi\SettingsPage\TabSettingsPage;

class SettingsProvider implements SettingsProviderInterface {

	use TemplateRendererTrait;

	protected $plugin;

	/**
	 * @var PluginOptions
	 */
	protected $baseOptions;

	/**
	 * SettingsProvider constructor.
	 *
	 * @param PluginOptions $baseOptions
	 */
	public function __construct(
		Plugin $plugin,
		PluginOptions $baseOptions
	) {
		$this->plugin      = $plugin;
		$this->baseOptions = $baseOptions;
	}

	/**
	 * @inheritDoc
	 */
	public function getSettingsSubmenu() {

		$baseOptions = $this->baseOptions;

		$submenu = new TabSettingsPage(
			sprintf( __( '%s Settings', Plugin::TEXT_DOMAIN ), $this->plugin->name ),
			sprintf( __( '%s Settings', Plugin::TEXT_DOMAIN ), $this->plugin->name ),
			'administrator',
			'expert-review'
		);

//		$submenu->setParentSlug( 'edit.php?post_type=' . MyPopup::POST_TYPE );

		$submenu->addSection( $section = new Section(
			$baseOptions->getSection(),
			__( 'Main', Plugin::TEXT_DOMAIN ),
			PluginOptions::class
		) );

		$section->addField( $field = new Text( 'license' ) );
		$field
			->setLabel( __( 'License', Plugin::TEXT_DOMAIN ) )
			->setPlaceholder( $baseOptions->license ? '*****' : __( 'Enter license key', Plugin::TEXT_DOMAIN ) )
			->setValue( $baseOptions->show_license_key ? null : '' )
			->setSanitizeCallback( function ( $value ) use ( $baseOptions ) {
				if ( ! $value && ! $baseOptions->show_license_key ) {
					$value = $baseOptions->license;
				}
				$value = trim( $value );
				if ( current_user_can( 'administrator' ) && $value ) {
					$this->plugin->activate( $value );
				}

				return null;
			} )
		;

		$section->addField( $field = new Checkbox( 'show_license_key' ) );
		$field
			->setLabel( __( 'Show License', Plugin::TEXT_DOMAIN ) )
			->setDescription( __( 'Show license key in input', Plugin::TEXT_DOMAIN ) )
			->setEnabled( current_user_can( 'administrator' ) )
		;

		$expertOptions = new ExpertOptions();
		$submenu->addSection( $section = new Section(
			$expertOptions->getSection(),
			__( 'Experts', Plugin::TEXT_DOMAIN ),
			$expertOptions
		) );

		$section->addField( $field = new RawHtml( 'experts' ) );
		$field
			->setRenderCallback(function ($id, $name, $value){
				$name    = $name ?: $id;
				$experts = $value ? json_decode( $value, true ) : [];
				echo $this->render('experts', [
					'name' => $name,
					'value' => $value,
					'experts' => $experts
				]);
			});

		return $submenu;
	}
}
