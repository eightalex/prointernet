<?php

namespace Wpshop\ExpertReview;

class Question {

	/**
	 * @return void
	 */
	public function init() {
		$this->setup_ajax();

		do_action( __METHOD__, $this );
	}

	/**
	 * @return void
	 */
	protected function setup_ajax() {
		add_action( 'wp_ajax_expert_review_submit_question', [ $this, '_submit_question' ] );
		add_action( 'wp_ajax_nopriv_expert_review_submit_question', [ $this, '_submit_question' ] );
	}

	/**
	 * @return void
	 */
	public function _submit_question() {
		if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'wpshop-nonce' ) ) {
			wp_send_json_error( [ 'message' => 'Forbidden' ] );
		}

		if ( isset( $_REQUEST['data'] ) ) {
			$data = array_map( 'trim', $_REQUEST['data'] );
			if ( ! empty( $data['email'] ) ) { // bot detected
				wp_send_json_error( [ 'message' => 'Forbidden' ] );
			}

			if ( empty( $data['name'] ) || empty( $data['_a'] ) ) {
				wp_send_json_error( [ 'message' => 'Unable to send email without mail or name data' ] );
			}

			if ( ! is_email( $data['_a'] ) ) {
				wp_send_json_error( [ 'message' => __( 'Please, fill email field', Plugin::TEXT_DOMAIN ) ] );
			}

			$message = wp_strip_all_tags( $data['text'] );
			$message = esc_html( sprintf(
					__( "Question from: %s <%s>, page: %s\n\n", Plugin::TEXT_DOMAIN ),
					$data['name'],
					$data['_a'],
					$_SERVER['HTTP_REFERER']
				) ) . $message;
			$message = wpautop( $message );

			if ( wp_mail(
				get_option( 'admin_email' ),
				sprintf( __( 'Question to Expert from %s', Plugin::TEXT_DOMAIN ), $data['name'] ),
				$message,
				[
					'Content-Type: text/html',
					"Reply-To: {$data['name']} <{$data['_a']}>",
				]
			) ) {
				wp_send_json_success();
			} else {
				wp_send_json_error( [ 'message' => __( 'Unable to send email', Plugin::TEXT_DOMAIN ) ] );
			}
		}
		wp_send_json_error( [ 'message' => 'Unable to handle request without data' ] );
	}
}
