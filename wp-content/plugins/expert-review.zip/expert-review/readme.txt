=== Expert Review ===

Contributors:      wpshopbiz
Requires at least: 4.5
Tested up to:      5.3
Requires PHP:      5.5
Stable tag:        1.0.0
License:           WPShop License
License URI:       https://wpshop.ru/license
Tags:              expert content, expert blocks, expert

== Description ==

Plugin helps to create expert content on your site.

== Installation ==

1. Upload `expert-review` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Changelog ==

= 1.1.1 - 2019-01-16 =
* Fix updates

= 1.1.0 - 2019-01-16 =
* Add page where from question was
* Release 1.1.0

= 1.0.1 - 2019-01-16 =
* Fix bugs
* Add composer.lock to git

= 1.0.0 - 2019-01-15 =
* First release
