<?php

if ( ! defined( 'WPINC' ) ) {
	die;
}

use Wpshop\ExpertReview\ExpertReviewLoader;
use Wpshop\ExpertReview\Question;
use Wpshop\ExpertReview\ExpertReview;
use Wpshop\ExpertReview\Plugin;
use Wpshop\ExpertReview\Settings\PluginOptions;
use Pimple\Container;
use Wpshop\ExpertReview\SettingsProvider;
use Wpshop\ExpertReview\Shortcodes;
use Wpshop\SettingApi\SettingsManagerProvider;

return function ( $config ) {
	global $wpdb;

	$container = new Container( [
		'config'                  => $config,
		Plugin::class             => function ( $c ) {
			return new Plugin( $c['config']['plugin_config'], $c[ PluginOptions::class ] );
		},
		ExpertReview::class       => function ( $c ) {
			return new ExpertReview(
				$c[ Plugin::class ],
				$c[ PluginOptions::class ]
			);
		},
		PluginOptions::class      => function () {
			return new PluginOptions();
		},
		SettingsProvider::class   => function ( $c ) {
			return new SettingsProvider(
				$c[ Plugin::class ],
				$c[ PluginOptions::class ]
			);
		},
		Shortcodes::class         => function ( $c ) {
			return new Shortcodes( $c[ Plugin::class ] );
		},
		ExpertReviewLoader::class => function () {
			return new ExpertReviewLoader();
		},
		Question::class           => function () {
			return new Question();
		},
	] );

	if ( class_exists( SettingsManagerProvider::class ) ) {
		$container->register( new SettingsManagerProvider() );
	}

	return $container;
};
