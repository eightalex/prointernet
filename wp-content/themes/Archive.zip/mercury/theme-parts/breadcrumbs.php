<?php if ( function_exists('yoast_breadcrumb') ) { ?>
	<div class="space-single-aces-breadcrumbs relative">
		<?php yoast_breadcrumb('<div class="space-breadcrumbs relative">','</div>'); ?>
	</div>
<?php } ?>